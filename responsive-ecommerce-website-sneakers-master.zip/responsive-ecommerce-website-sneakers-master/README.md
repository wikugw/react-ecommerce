# Responsive Ecommerce Website Sneakers
## [Watch it on youtube](https://youtu.be/-EM4uVJm9qo)
### Responsive Ecommerce Website Sneakers
Beautiful Responsive Ecommerce Website. It has a header and a home page showing an image and data of a product, it also has a features section, a women's sneakers section, a collection section, a offers section and a footer. It also has its own page to see all the products. Developed totally mobile first and then desktop.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
